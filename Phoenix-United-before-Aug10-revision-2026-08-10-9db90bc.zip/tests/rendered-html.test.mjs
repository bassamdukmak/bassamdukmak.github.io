import assert from "node:assert/strict";
import test from "node:test";
import { env as workerEnv } from "./cloudflare-workers.mock.mjs";
import { FakeD1 } from "./fake-d1.mjs";

const templateRoot = new URL("../", import.meta.url);
let workerSequence = 0;

async function worker() {
  const workerUrl = new URL("dist/server/index.js", templateRoot);
  workerUrl.searchParams.set("test", `${process.pid}-${workerSequence++}`);
  const workerModule = await import(workerUrl.href);
  return workerModule.default;
}

const runtimeEnv = {
  ASSETS: {
    fetch: async () => new Response("Not found", { status: 404 }),
  },
};

const runtimeContext = {
  waitUntil() {},
  passThroughOnException() {},
};

const configuredKeys = [
  "DB",
  "CRM_WEBHOOK_URL",
  "CRM_WEBHOOK_SECRET",
  "CRM_SYNC_SECRET",
  "GA4_MEASUREMENT_ID",
  "META_PIXEL_ID",
];

function configureWorkerEnv(values = {}) {
  for (const key of configuredKeys) delete workerEnv[key];
  Object.assign(workerEnv, values);
}

function birthDateForAge(age) {
  const today = new Date();
  return `${today.getUTCFullYear() - age}-${String(
    today.getUTCMonth() + 1,
  ).padStart(2, "0")}-${String(today.getUTCDate()).padStart(2, "0")}`;
}

function validPlayer(overrides = {}) {
  return {
    leadType: "player",
    idempotencyKey: "test-idempotency-key-12345",
    fullName: "Test Player",
    email: "player@example.com",
    phone: "+971500000000",
    country: "United Arab Emirates",
    dateOfBirth: birthDateForAge(20),
    nationality: "Syrian",
    position: "midfielder",
    currentClub: "Test FC",
    playingLevel: "professional_academy_or_pro_youth",
    highlightUrl: "https://www.youtube.com/watch?v=phoenix-test",
    preferredRoute: "football_degree",
    preferredHub: "dubai",
    readinessTimeline: "next_3_6_months",
    budgetReadiness: "needs_payment_plan",
    familySupport: "fully_involved_supportive",
    referralName: "Coach Example",
    consent: true,
    formStartedAt: Date.now() - 5_000,
    ...overrides,
  };
}

function submitLead(app, payload, headers = {}) {
  return app.fetch(
    new Request("http://localhost/api/leads", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        origin: "http://localhost",
        ...headers,
      },
      body: JSON.stringify(payload),
    }),
    runtimeEnv,
    runtimeContext,
  );
}

test("server-renders the Phoenix club homepage", async () => {
  configureWorkerEnv();
  const app = await worker();
  const response = await app.fetch(
    new Request("http://localhost/", {
      headers: { accept: "text/html", host: "localhost" },
    }),
    runtimeEnv,
    runtimeContext,
  );

  assert.equal(response.status, 200);
  assert.match(response.headers.get("content-type") ?? "", /^text\/html\b/i);

  const html = await response.text();
  assert.match(
    html,
    /<title>Phoenix United FC \| Football Club in Dubai<\/title>/i,
  );
  assert.match(html, /property="og:image" content="http:\/\/localhost\/og\.png"/i);
  assert.match(html, /A football club in Dubai/i);
  assert.match(html, /built to rise/i);
  assert.doesNotMatch(html, /UAE FA club/i);
  assert.match(html, /A real club first/i);
  assert.match(html, /Built by brothers/i);
  assert.match(html, /Leadership &amp; key people/i);
  assert.match(html, /Radcliffe FC/i);
  assert.match(html, /Manchester/i);
  assert.match(html, /Algarve/i);
  assert.match(html, /Phoenix club partners/i);
  assert.match(html, /partners\/radcliffe\.svg/i);
  assert.match(html, /partners\/silves\.png/i);
  assert.doesNotMatch(html, /Our identity|Rebirth in the badge/i);
  assert.doesNotMatch(html, /partner-rail-track/i);
  assert.match(html, /Press room/i);
  assert.match(html, /Start Your Pathway/i);
  assert.match(html, /phoenix_utdfc/);
  assert.doesNotMatch(
    html,
    /codex-preview|SkeletonPreview|react-loading-skeleton/i,
  );
  assert.doesNotMatch(html, /AI-generated|AI concept image/i);
});

test("server-renders the complete Phoenix pathway assessment", async () => {
  configureWorkerEnv();
  const app = await worker();
  const response = await app.fetch(
    new Request("http://localhost/pathway", {
      headers: { accept: "text/html", host: "localhost" },
    }),
    runtimeEnv,
    runtimeContext,
  );

  assert.equal(response.status, 200);
  const html = await response.text();
  assert.match(
    html,
    /<title>Phoenix Football Network \| Football\. Degree\. Pathway\.<\/title>/i,
  );
  assert.match(
    html,
    /name="twitter:title" content="Phoenix Football Network \| Start Your Pathway"/i,
  );
  assert.match(html, /property="og:image" content="http:\/\/localhost\/og\.png"/i);
  assert.match(html, /Train with purpose/i);
  assert.match(html, /Play with direction/i);
  assert.match(html, /Football \+ Degree/i);
  assert.match(html, /Manchester/i);
  assert.match(html, /Portugal/i);
  assert.match(html, /US pathway assessment stages/i);
  assert.match(html, /Eligibility/i);
  assert.match(html, /Recruitment/i);
  assert.match(html, /About you/i);
  assert.match(html, /Football background/i);
  assert.match(html, /Route &amp; readiness/i);
  assert.match(html, /Date of birth/i);
  assert.match(html, /Nationality/i);
  assert.match(html, /Current country of residence/i);
  assert.match(html, /Phone \/ WhatsApp|WhatsApp number/i);
  assert.match(html, />Partnership</i);
  assert.match(html, /<form\b[^>]*noValidate/i);
  assert.doesNotMatch(html, /guardianName|educationLevel|accommodationPreference/i);
  assert.doesNotMatch(html, /guaranteed scholarship|guaranteed contract/i);
});

test("server-renders the planned store without a false checkout", async () => {
  configureWorkerEnv();
  const app = await worker();
  const response = await app.fetch(
    new Request("http://localhost/store", {
      headers: { accept: "text/html", host: "localhost" },
    }),
    runtimeEnv,
    runtimeContext,
  );

  assert.equal(response.status, 200);
  const html = await response.text();
  assert.match(html, /<title>Phoenix Store \| Wear the Rise<\/title>/i);
  assert.match(
    html,
    /name="twitter:title" content="Phoenix Store \| Wear the Rise"/i,
  );
  assert.match(html, /property="og:image" content="http:\/\/localhost\/og\.png"/i);
  assert.match(html, /Kits as/i);
  assert.match(html, /culture/i);
  assert.match(html, /26\/27 Preview/i);
  assert.match(html, /Collection architecture/i);
  assert.match(html, /One badge\. Five expressions\./i);
  assert.match(html, /Matchday/i);
  assert.match(html, /Training/i);
  assert.match(html, /Premium limited/i);
  assert.match(html, /\/kits\/matchday-black-front\.webp/i);
  assert.match(html, /aria-pressed="true"/i);
  assert.doesNotMatch(html, /type="radio"/i);
  assert.doesNotMatch(
    html,
    /<img[^>]+src="\/kits\/matchday-black-back\.webp"/i,
  );
  assert.doesNotMatch(html, /\/kits\/[^"']+\.jpe?g/i);
  assert.doesNotMatch(html, /Add to cart|Proceed to checkout|Buy now/i);
});

test("privacy page renders route-specific social metadata", async () => {
  configureWorkerEnv();
  const app = await worker();
  const response = await app.fetch(
    new Request("http://localhost/privacy", {
      headers: { accept: "text/html", host: "localhost" },
    }),
    runtimeEnv,
    runtimeContext,
  );

  assert.equal(response.status, 200);
  const html = await response.text();
  assert.match(
    html,
    /property="og:title" content="Website Privacy Notice \| Phoenix United FC"/i,
  );
  assert.match(
    html,
    /property="og:url" content="http:\/\/localhost\/privacy"/i,
  );
  assert.match(
    html,
    /name="twitter:title" content="Website Privacy Notice \| Phoenix United FC"/i,
  );
  assert.doesNotMatch(
    html,
    /property="og:title" content="Phoenix United FC \| A football club/i,
  );
});

test("lead endpoint rejects incomplete submissions before storage", async () => {
  configureWorkerEnv();
  const app = await worker();
  const response = await submitLead(app, {
    leadType: "player",
    idempotencyKey: "test-idempotency-key-12345",
  });

  assert.equal(response.status, 400);
  const body = await response.json();
  assert.match(body.error, /valid name and email/i);
});

test("lead endpoint derives age from DOB and rejects players outside 18–25", async () => {
  configureWorkerEnv();
  const app = await worker();

  for (const age of [17, 26]) {
    const response = await submitLead(
      app,
      validPlayer({
        dateOfBirth: birthDateForAge(age),
        idempotencyKey: `test-age-${age}-key-123456789`,
      }),
    );

    assert.equal(response.status, 400);
    const body = await response.json();
    assert.match(body.error, /currently for ages 18–25/i);
    assert.match(body.error, /amer@phoenixutd\.com/i);
  }
});

test("player assessment rejects incomplete or invalid qualification fields", async () => {
  configureWorkerEnv();
  const app = await worker();
  const invalidCases = [
    [{ fullName: "A" }, /valid name and email/i],
    [{ email: "not-an-email" }, /valid name and email/i],
    [{ phone: "123456" }, /phone number and current country/i],
    [{ country: "" }, /phone number and current country/i],
    [{ consent: false }, /consent is required/i],
    [{ dateOfBirth: "not-a-date" }, /valid date of birth/i],
    [{ nationality: "" }, /nationality/i],
    [{ position: "striker" }, /player position/i],
    [{ currentClub: "" }, /current club/i],
    [{ playingLevel: "" }, /playing level/i],
    [{ playingLevel: "elite_invitation" }, /playing level/i],
    [{ highlightUrl: "http://127.0.0.1/highlights" }, /valid public match/i],
    [{ preferredRoute: "guaranteed_contract" }, /pathway route/i],
    [{ preferredHub: "algarve" }, /preferred phoenix hub/i],
    [{ readinessTimeline: "" }, /readiness timeline/i],
    [{ budgetReadiness: "" }, /budget readiness/i],
    [{ familySupport: "" }, /family support/i],
  ];

  for (const [overrides, expectedError] of invalidCases) {
    const response = await submitLead(
      app,
      validPlayer({
        ...overrides,
        idempotencyKey: `invalid-player-${crypto.randomUUID()}`,
      }),
    );

    assert.equal(response.status, 400);
    const body = await response.json();
    assert.match(body.error, expectedError);
  }
});

test("player DOB and supplied assessment answers are persisted", async () => {
  const database = new FakeD1();
  configureWorkerEnv({ DB: database });
  const app = await worker();
  const response = await submitLead(
    app,
    validPlayer({ idempotencyKey: "supplied-assessment-123456789" }),
  );
  assert.equal(response.status, 201);
  assert.equal(database.leads[0].applicant_role, "player");
  assert.equal(database.leads[0].date_of_birth, birthDateForAge(20));
  assert.equal(database.leads[0].player_age, 20);
  assert.equal(database.leads[0].nationality, "Syrian");
  assert.equal(database.leads[0].readiness_timeline, "next_3_6_months");
  assert.equal(database.leads[0].budget_readiness, "needs_payment_plan");
  assert.equal(database.leads[0].family_support, "fully_involved_supportive");
  assert.equal(database.leads[0].referral_name, "Coach Example");
});

test("partnership enquiry validation and persistence remain unchanged", async () => {
  const database = new FakeD1();
  configureWorkerEnv({ DB: database });
  const app = await worker();
  const response = await submitLead(app, {
    leadType: "partner",
    idempotencyKey: "partner-enquiry-unchanged-123456789",
    fullName: "Partner Contact",
    email: "partner@example.com",
    phone: "+971501111111",
    country: "United Arab Emirates",
    organization: "Example Football Group",
    partnerInterest: "club_academy",
    message:
      "We would like to discuss a structured club partnership with Phoenix.",
    dateOfBirth: birthDateForAge(22),
    nationality: "Stale nationality",
    preferredRoute: "football_degree",
    preferredHub: "dubai",
    position: "midfielder",
    currentClub: "Stale Player FC",
    playingLevel: "professional_academy_or_pro_youth",
    highlightUrl: "https://youtube.com/watch?v=stale-player",
    readinessTimeline: "next_1_3_months",
    budgetReadiness: "ready_full_pricing",
    familySupport: "fully_involved_supportive",
    referralName: "Stale referrer",
    collectionInterest: "matchday",
    contactPreference: "whatsapp",
    consent: true,
    formStartedAt: Date.now() - 5_000,
  });

  assert.equal(response.status, 201);
  assert.equal(database.leads.length, 1);
  assert.equal(database.leads[0].lead_type, "partner");
  assert.equal(database.leads[0].applicant_role, "partner");
  assert.equal(database.leads[0].organization, "Example Football Group");
  assert.equal(database.leads[0].guardian_name, "");
  assert.equal(database.leads[0].date_of_birth, "");
  assert.equal(database.leads[0].nationality, "");
  assert.equal(database.leads[0].preferred_hub, "");
  assert.equal(database.leads[0].accommodation_preference, "");
  assert.equal(database.leads[0].player_age, null);
  assert.equal(database.leads[0].preferred_route, "");
  assert.equal(database.leads[0].position, "");
  assert.equal(database.leads[0].current_club, "");
  assert.equal(database.leads[0].playing_level, "");
  assert.equal(database.leads[0].highlight_url, "");
  assert.equal(database.leads[0].education_level, "");
  assert.equal(database.leads[0].intended_study, "");
  assert.equal(database.leads[0].preferred_intake, "");
  assert.equal(database.leads[0].readiness_timeline, "");
  assert.equal(database.leads[0].budget_readiness, "");
  assert.equal(database.leads[0].family_support, "");
  assert.equal(database.leads[0].referral_name, "");
  assert.equal(database.leads[0].collection_interest, "");
  assert.equal(database.leads[0].goal, "");

  const invalidAreaResponse = await submitLead(app, {
    leadType: "partner",
    idempotencyKey: "partner-enquiry-invalid-area-123456789",
    fullName: "Another Partner Contact",
    email: "another-partner@example.com",
    phone: "+971502222222",
    country: "United Arab Emirates",
    organization: "Another Football Group",
    partnerInterest: "bespoke_sponsorship_tier",
    message:
      "We would like to discuss a structured partnership with Phoenix United.",
    contactPreference: "email",
    consent: true,
    formStartedAt: Date.now() - 5_000,
  });
  assert.equal(invalidAreaResponse.status, 400);
  assert.match((await invalidAreaResponse.json()).error, /partnership area/i);
  assert.equal(database.leads.length, 1);
});

test("kit interest accepts the Store payload with optional phone and message", async () => {
  const database = new FakeD1();
  configureWorkerEnv({ DB: database });
  const app = await worker();
  const response = await submitLead(app, {
    leadType: "kit_interest",
    idempotencyKey: "kit-interest-store-form-123456789",
    fullName: "Kit Supporter",
    email: "supporter@example.com",
    phone: "",
    country: "Canada",
    collectionInterest: "premium_limited",
    message: "",
    consent: true,
    formStartedAt: Date.now() - 5_000,
    website: "",
    sourceUrl: "https://phoenixutd.com/store?utm_source=instagram",
    referrer: "https://www.instagram.com/",
    utmSource: "instagram",
    utmMedium: "social",
    utmCampaign: "kit-preview",
    formVariant: "store_interest_v1",
  });

  assert.equal(response.status, 201);
  assert.deepEqual(await response.json(), {
    created: true,
    leadReference: "PX-00001",
    message:
      "Your kit interest has been received. Phoenix will contact you when the collection is ready.",
  });
  assert.equal(database.leads[0].lead_type, "kit_interest");
  assert.equal(database.leads[0].applicant_role, "kit_interest");
  assert.equal(database.leads[0].phone, "");
  assert.equal(database.leads[0].collection_interest, "premium_limited");
  assert.equal(database.leads[0].utm_source, "instagram");
  assert.equal(database.leads[0].form_variant, "store_interest_v1");

  const invalidCollection = await submitLead(app, {
    leadType: "kit_interest",
    idempotencyKey: "kit-interest-invalid-collection-123456789",
    fullName: "Another Supporter",
    email: "another@example.com",
    country: "United Kingdom",
    collectionInterest: "secret_drop",
    consent: true,
    formStartedAt: Date.now() - 5_000,
  });
  assert.equal(invalidCollection.status, 400);
  assert.match((await invalidCollection.json()).error, /choose a phoenix collection/i);
  assert.equal(database.leads.length, 1);
});

test("honeypot submissions are acknowledged without touching storage", async () => {
  configureWorkerEnv();
  const app = await worker();
  const response = await submitLead(
    app,
    validPlayer({ website: "https://spam.example" }),
  );

  assert.equal(response.status, 201);
  const body = await response.json();
  assert.equal(body.created, false);
  assert.equal(body.leadReference, undefined);
});

test("complete player assessment is persisted before an authenticated CRM delivery", async (t) => {
  const database = new FakeD1();
  const webhookSecret = "crm-webhook-secret-for-tests";
  configureWorkerEnv({
    DB: database,
    CRM_WEBHOOK_URL: "https://crm.example.test/webhooks/phoenix",
    CRM_WEBHOOK_SECRET: webhookSecret,
  });
  const app = await worker();
  let capturedRequest;

  t.mock.method(globalThis, "fetch", async (input, init) => {
    assert.equal(database.leads.length, 1, "lead must exist before delivery");
    assert.equal(database.leads[0].crm_status, "queued");
    capturedRequest = { input, init };
    return new Response("accepted", { status: 202 });
  });

  const payload = validPlayer({
    idempotencyKey: "completed-assessment-success-123456789",
    fullName: "Samir Haddad",
    email: "SAMIR@example.com",
    dateOfBirth: birthDateForAge(21),
    nationality: "Syrian",
    position: "forward",
    currentClub: "Al Nasr U21",
    playingLevel: "semi_professional_or_regional",
    highlightUrl: "https://www.youtube.com/watch?v=samir-phoenix",
    preferredRoute: "football_degree",
    preferredHub: "dubai",
    readinessTimeline: "next_3_6_months",
    budgetReadiness: "ready_full_pricing",
    familySupport: "fully_involved_supportive",
    referralName: "Coach Karim",
    sourceUrl:
      "https://phoenixutd.com/?utm_source=instagram&utm_campaign=founding-class",
    referrer: "https://www.instagram.com/",
    utmSource: "instagram",
    utmMedium: "social",
    utmCampaign: "founding-class",
    utmContent: "training-reel",
    utmTerm: "football degree",
    gclid: "google-click",
    fbclid: "meta-click",
    language: "en-AE",
    timezone: "Asia/Dubai",
    formVariant: "pathway-assessment-v4",
  });
  const response = await submitLead(app, payload);
  const responseBody = await response.json();

  assert.equal(response.status, 201);
  assert.deepEqual(responseBody, {
    created: true,
    leadReference: "PX-00001",
    message:
      "Thank you for submitting your player pathway assessment. Our team will review the details and contact you with the most suitable next step.",
  });
  assert.equal(database.leads.length, 1);
  assert.equal(database.leads[0].email, "samir@example.com");
  assert.equal(database.leads[0].applicant_role, "player");
  assert.equal(database.leads[0].guardian_name, "");
  assert.equal(database.leads[0].date_of_birth, birthDateForAge(21));
  assert.equal(database.leads[0].nationality, "Syrian");
  assert.equal(database.leads[0].player_age, 21);
  assert.equal(database.leads[0].preferred_hub, "dubai");
  assert.equal(database.leads[0].readiness_timeline, "next_3_6_months");
  assert.equal(database.leads[0].budget_readiness, "ready_full_pricing");
  assert.equal(database.leads[0].family_support, "fully_involved_supportive");
  assert.equal(database.leads[0].crm_status, "synced");
  assert.equal(database.leads[0].crm_attempts, 1);
  assert.deepEqual(
    database.events.map((event) => event.type),
    ["insert", "update"],
  );

  assert.equal(
    String(capturedRequest.input),
    "https://crm.example.test/webhooks/phoenix",
  );
  assert.equal(capturedRequest.init.method, "POST");
  const headers = new Headers(capturedRequest.init.headers);
  assert.equal(headers.get("content-type"), "application/json");
  assert.equal(headers.get("authorization"), `Bearer ${webhookSecret}`);
  assert.equal(headers.get("idempotency-key"), "PX-00001");
  assert.deepEqual(JSON.parse(capturedRequest.init.body), {
    event: "phoenix.website.lead.created",
    leadReference: "PX-00001",
    stage: "New",
    submittedAt: database.leads[0].created_at,
    leadType: "player",
    applicantRole: "player",
    guardianName: "",
    fullName: "Samir Haddad",
    email: "samir@example.com",
    phone: "+971500000000",
    country: "United Arab Emirates",
    dateOfBirth: birthDateForAge(21),
    nationality: "Syrian",
    playerAge: 21,
    position: "forward",
    currentClub: "Al Nasr U21",
    playingLevel: "semi_professional_or_regional",
    highlightUrl: "https://www.youtube.com/watch?v=samir-phoenix",
    educationLevel: "",
    intendedStudy: "",
    preferredRoute: "football_degree",
    preferredHub: "dubai",
    accommodationPreference: "",
    preferredIntake: "",
    readinessTimeline: "next_3_6_months",
    budgetReadiness: "ready_full_pricing",
    familySupport: "fully_involved_supportive",
    referralName: "Coach Karim",
    collectionInterest: "",
    goal: "",
    organization: "",
    partnerInterest: "",
    message: "",
    contactPreference: "",
    consent: true,
    sourceUrl:
      "https://phoenixutd.com/?utm_source=instagram&utm_campaign=founding-class",
    referrer: "https://www.instagram.com/",
    utmSource: "instagram",
    utmMedium: "social",
    utmCampaign: "founding-class",
    utmContent: "training-reel",
    utmTerm: "football degree",
    gclid: "google-click",
    fbclid: "meta-click",
    language: "en-AE",
    timezone: "Asia/Dubai",
    formVariant: "pathway-assessment-v4",
  });
});

test("duplicate submissions return the original reference without inserting again", async () => {
  const database = new FakeD1();
  configureWorkerEnv({ DB: database });
  const app = await worker();
  const payload = validPlayer({
    idempotencyKey: "duplicate-submission-123456789",
  });

  const firstResponse = await submitLead(app, payload);
  const firstBody = await firstResponse.json();
  const duplicateResponse = await submitLead(app, payload);
  const duplicateBody = await duplicateResponse.json();

  assert.equal(firstResponse.status, 201);
  assert.equal(firstBody.created, true);
  assert.equal(duplicateResponse.status, 200);
  assert.deepEqual(duplicateBody, {
    created: false,
    leadReference: "PX-00001",
    message:
      "Your enquiry is already safely received. Phoenix will review it and contact you about the appropriate next step.",
  });
  assert.equal(database.leads.length, 1);
  assert.equal(
    database.events.filter((event) => event.type === "insert").length,
    1,
  );
});

test("concurrent duplicate submissions resolve to one stored lead", async () => {
  const database = new FakeD1();
  configureWorkerEnv({ DB: database });
  const app = await worker();
  const payload = validPlayer({
    idempotencyKey: "concurrent-duplicate-123456789",
  });

  const responses = await Promise.all([
    submitLead(app, payload),
    submitLead(app, payload),
  ]);
  const bodies = await Promise.all(responses.map((response) => response.json()));

  assert.deepEqual(
    responses.map((response) => response.status).sort(),
    [200, 201],
  );
  assert.deepEqual(
    bodies.map((body) => body.created).sort(),
    [false, true],
  );
  assert.ok(bodies.every((body) => body.leadReference === "PX-00001"));
  assert.equal(database.leads.length, 1);
});

test("lead rate limiting rejects the thirteenth request in ten minutes", async () => {
  const database = new FakeD1();
  configureWorkerEnv({ DB: database });
  const app = await worker();
  const payload = validPlayer({
    idempotencyKey: "rate-limit-duplicate-123456789",
  });
  const statuses = [];

  for (let attempt = 0; attempt < 13; attempt += 1) {
    const response = await submitLead(app, payload, {
      "cf-connecting-ip": "203.0.113.8",
    });
    statuses.push(response.status);
  }

  assert.equal(statuses[0], 201);
  assert.ok(statuses.slice(1, 12).every((status) => status === 200));
  assert.equal(statuses[12], 429);
  assert.equal(database.leads.length, 1);
});

test("CRM timeout remains queued and the protected sync endpoint retries it", async (t) => {
  const database = new FakeD1();
  const syncSecret = "manual-sync-secret-123456";
  configureWorkerEnv({
    DB: database,
    CRM_WEBHOOK_URL: "https://crm.example.test/webhooks/phoenix",
    CRM_WEBHOOK_SECRET: "crm-webhook-secret-for-tests",
    CRM_SYNC_SECRET: syncSecret,
  });
  const app = await worker();
  let shouldTimeout = true;
  let deliveryAttempts = 0;

  t.mock.method(globalThis, "fetch", async () => {
    deliveryAttempts += 1;
    if (shouldTimeout) throw new Error("CRM request timed out");
    return new Response(null, { status: 204 });
  });

  const response = await submitLead(
    app,
    validPlayer({ idempotencyKey: "timeout-retry-key-123456789" }),
  );
  const responseBody = await response.json();

  assert.equal(response.status, 201);
  assert.equal(responseBody.created, true);
  assert.equal(database.leads[0].crm_status, "queued");
  assert.equal(database.leads[0].crm_attempts, 1);
  assert.match(database.leads[0].crm_response, /timed out/i);

  const unauthorized = await app.fetch(
    new Request("http://localhost/api/leads/sync", {
      method: "POST",
      headers: { authorization: "Bearer wrong-secret" },
    }),
    runtimeEnv,
    runtimeContext,
  );
  assert.equal(unauthorized.status, 401);
  assert.equal(deliveryAttempts, 1);

  shouldTimeout = false;
  const retryResponse = await app.fetch(
    new Request("http://localhost/api/leads/sync", {
      method: "POST",
      headers: { authorization: `Bearer ${syncSecret}` },
    }),
    runtimeEnv,
    runtimeContext,
  );

  assert.equal(retryResponse.status, 200);
  assert.deepEqual(await retryResponse.json(), {
    configured: true,
    attempted: 1,
    synced: 1,
    queued: 0,
  });
  assert.equal(deliveryAttempts, 2);
  assert.equal(database.leads[0].crm_status, "synced");
  assert.equal(database.leads[0].crm_attempts, 2);
});

test("a queue infrastructure error never turns a saved lead into a resubmit", async (t) => {
  const database = new FakeD1();
  database.failQueuedSelect = true;
  configureWorkerEnv({
    DB: database,
    CRM_WEBHOOK_URL: "https://crm.example.test/webhooks/phoenix",
    CRM_WEBHOOK_SECRET: "crm-webhook-secret-for-tests",
  });
  const app = await worker();
  const fetchMock = t.mock.method(globalThis, "fetch", async () => {
    throw new Error("Webhook should not be reached");
  });
  t.mock.method(console, "error", () => {});

  const response = await submitLead(
    app,
    validPlayer({ idempotencyKey: "queue-read-failure-123456789" }),
  );
  const body = await response.json();

  assert.equal(response.status, 201);
  assert.equal(body.created, true);
  assert.equal(body.leadReference, "PX-00001");
  assert.equal(database.leads.length, 1);
  assert.equal(database.leads[0].crm_status, "queued");
  assert.equal(fetchMock.mock.callCount(), 0);
});

test("CRM delivery stays queued until both endpoint and bearer secret are configured", async (t) => {
  const database = new FakeD1();
  configureWorkerEnv({
    DB: database,
    CRM_WEBHOOK_URL: "https://crm.example.test/webhooks/phoenix",
  });
  const app = await worker();
  const fetchMock = t.mock.method(globalThis, "fetch", async () => {
    throw new Error("Unauthenticated webhook delivery is forbidden");
  });

  const response = await submitLead(
    app,
    validPlayer({ idempotencyKey: "missing-bearer-secret-123456789" }),
  );

  assert.equal(response.status, 201);
  assert.equal(database.leads[0].crm_status, "queued");
  assert.equal(database.leads[0].crm_attempts, 0);
  assert.equal(fetchMock.mock.callCount(), 0);
});

test("tracking config exposes only validated public measurement IDs", async () => {
  configureWorkerEnv({
    GA4_MEASUREMENT_ID: "G-ABC1234567",
    META_PIXEL_ID: "123456789012345",
  });
  const app = await worker();
  const validResponse = await app.fetch(
    new Request("http://localhost/api/tracking-config"),
    runtimeEnv,
    runtimeContext,
  );

  assert.equal(validResponse.status, 200);
  assert.equal(
    validResponse.headers.get("cache-control"),
    "public, max-age=300",
  );
  assert.deepEqual(await validResponse.json(), {
    ga4MeasurementId: "G-ABC1234567",
    metaPixelId: "123456789012345",
  });

  configureWorkerEnv({
    GA4_MEASUREMENT_ID: "G-ABC123<script>",
    META_PIXEL_ID: "12345<script>",
  });
  const invalidResponse = await app.fetch(
    new Request("http://localhost/api/tracking-config"),
    runtimeEnv,
    runtimeContext,
  );
  assert.deepEqual(await invalidResponse.json(), {
    ga4MeasurementId: "",
    metaPixelId: "",
  });
});
