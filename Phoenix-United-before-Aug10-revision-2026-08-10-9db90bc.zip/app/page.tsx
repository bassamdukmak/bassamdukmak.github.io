/* eslint-disable @next/next/no-img-element */
import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import PartnerRail from "./components/partner-rail";
import {
  SiteFooter,
  SiteHeader,
  TrackingConsent,
} from "./components/site-chrome";
import {
  approvedPartnerLogos,
  leadershipPeople,
  learningPeople,
} from "./content/site-content";

export const metadata: Metadata = {
  title: {
    absolute: "Phoenix United FC | Football Club in Dubai",
  },
  description:
    "Phoenix United FC is a UAE FA licensed football club in Dubai, built for ambitious players and connected to an international football network.",
  alternates: {
    canonical: "/",
  },
  openGraph: {
    type: "website",
    url: "/",
    siteName: "Phoenix United FC",
    title: "Phoenix United FC | A football club in Dubai, built to rise.",
    description:
      "The competitive heart of the Phoenix ecosystem: club football, culture and international connections from Dubai.",
    images: [
      {
        url: "/og.png",
        width: 1200,
        height: 630,
        alt: "Phoenix United FC — a football club in Dubai, built to rise.",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Phoenix United FC | A football club in Dubai, built to rise.",
    description:
      "The competitive heart of the Phoenix ecosystem: club football, culture and international connections from Dubai.",
    images: ["/og.png"],
  },
};

const networkStops = [
  {
    code: "DXB 01",
    city: "Dubai",
    country: "United Arab Emirates",
    club: "Phoenix United FC",
    role: "Home",
    copy: "The club, the daily football environment and the centre of the Phoenix ecosystem.",
    image: "/images/dubai-hub.jpg",
    alt: "Phoenix players together after a training session in Dubai",
  },
  {
    code: "MAN 02",
    city: "Manchester",
    country: "England",
    club: "Radcliffe FC",
    role: "Connect",
    copy: "The Manchester connection and a bridge into community-rooted English football.",
    image: "/images/manchester-hub.jpg",
    alt: "Supporters watching Radcliffe FC in Greater Manchester",
  },
  {
    code: "ALG 03",
    city: "Silves, Algarve",
    country: "Portugal",
    club: "Silves FC",
    role: "Develop",
    copy: "The Portuguese connection for camps, showcases and development activity when announced.",
    image: "/images/algarve-hub.jpg",
    alt: "Phoenix representatives at a football ground in Portugal",
  },
];

export default function ClubPage() {
  return (
    <div className="final-site club-page">
      <SiteHeader activePage="club" />
      <main id="main-content">
        <section className="club-hero" aria-labelledby="club-hero-title">
          <div className="club-hero-copy">
            <div className="club-mark">
              <img
                src="/brand/phoenix-crest.svg"
                width={96}
                height={108}
                alt="Phoenix United FC crest"
              />
              <p>
                Phoenix United FC
                <span>Dubai · United Arab Emirates</span>
              </p>
            </div>
            <p className="final-kicker">The club · Strive to Rise</p>
            <h1 id="club-hero-title">
              A football club in Dubai, <em>built to rise.</em>
            </h1>
            <p className="club-hero-lede">
              A competitive club environment for ambitious players, connected
              to education and international routes beyond Dubai.
            </p>
            <div className="final-actions">
              <Link className="button button-primary" href="/pathway#assessment">
                Start Your Pathway
              </Link>
              <a className="button button-secondary" href="#who-we-are">
                Explore the Club
              </a>
            </div>
          </div>

          <figure className="club-hero-media">
            <div className="club-hero-image-frame">
              <Image
                src="/images/phoenix-squad-hero.webp"
                alt="Phoenix United players and coach together at the club ground in Dubai"
                fill
                priority
                unoptimized
                sizes="(max-width: 820px) 100vw, 58vw"
              />
            </div>
          </figure>
        </section>

        <section
          id="who-we-are"
          className="club-definition"
          aria-labelledby="who-we-are-title"
        >
          <figure className="club-definition-media">
            <Image
              src="/images/instagram-team.jpg"
              alt="Phoenix players together on the training pitch in Dubai"
              fill
              unoptimized
              sizes="(max-width: 820px) 100vw, 46vw"
            />
            <figcaption>
              <span>DXB 01</span>
              The club lives on the pitch.
            </figcaption>
          </figure>
          <div className="club-definition-copy">
            <p className="final-kicker">Who we are</p>
            <h2 id="who-we-are-title">
              A real club first. The heart of the ecosystem.
            </h2>
            <p className="editorial-lead">
              Phoenix United FC is a UAE FA licensed football club based in
              Dubai, built around competitive standards, a proper club culture
              and a wider international network.
            </p>
            <p>
              The club has its own players, coaches, partners and long-term
              ambition. Phoenix Football Network sits alongside it to connect
              football, education and pathway conversations.
            </p>
            <div className="club-definition-ledger" aria-label="The club environment">
              <span>Training</span>
              <span>Matchday</span>
              <span>Identity</span>
              <span>Community</span>
            </div>
          </div>
        </section>

        <section className="player-standard" aria-labelledby="standard-title">
          <div className="player-standard-copy">
            <p className="final-kicker">Why Phoenix</p>
            <h2 id="standard-title">A platform, not a ceiling.</h2>
            <p>
              Phoenix is for players who want structure, accountability and a
              competitive environment in Dubai while keeping more than one
              credible next step visible.
            </p>
            <ul>
              <li>
                <span>Compete</span>
                Earn your place inside a real club.
              </li>
              <li>
                <span>Develop</span>
                Work to a daily standard, not a shortcut.
              </li>
              <li>
                <span>Connect</span>
                Keep international football routes visible.
              </li>
              <li>
                <span>Belong</span>
                Carry a badge, a culture and a shared ambition.
              </li>
            </ul>
            <Link className="text-link" href="/pathway">
              See the pathway behind the club <span aria-hidden="true">→</span>
            </Link>
          </div>
          <figure className="player-standard-media">
            <Image
              src="/images/instagram-training.jpg"
              alt="A Phoenix player controlling the ball during a training session"
              fill
              unoptimized
              sizes="(max-width: 820px) 100vw, 50vw"
            />
            <figcaption>Standards live in the work.</figcaption>
          </figure>
        </section>

        <section className="founder-story" aria-labelledby="founder-title">
          <figure className="founder-media">
            <Image
              src="/media/founders-media-day.jpeg"
              alt="Phoenix leadership and partners together during the club media day"
              fill
              unoptimized
              style={{ objectFit: "contain" }}
              sizes="(max-width: 820px) 100vw, 58vw"
            />
            <figcaption>
              Phoenix leadership and partners during the club media day.
            </figcaption>
          </figure>

          <div className="founder-story-panel">
            <div className="founder-story-copy">
              <p className="final-kicker">Behind the Phoenix</p>
              <h2 id="founder-title">Built by brothers. Built for players.</h2>
              <p>
                Amer and Bader Al Akkad built Phoenix from Syrian foundations,
                Manchester roots and a Dubai future. The idea is simple: a
                player&apos;s entire future should not depend on one opportunity.
              </p>
              <div className="founder-route" aria-label="Phoenix founder journey">
                <span>Syrian foundations</span>
                <i aria-hidden="true" />
                <span>Manchester roots</span>
                <i aria-hidden="true" />
                <strong>Dubai future</strong>
              </div>
            </div>

            <div className="founder-people" aria-labelledby="people-title">
              <div className="people-heading">
                <p className="final-kicker">Leadership & key people</p>
                <h3 id="people-title">The people behind the build.</h3>
              </div>
              <div className="people-ledger">
                {leadershipPeople.map((person, index) => (
                  <article key={person.name}>
                    <i>{String(index + 1).padStart(2, "0")}</i>
                    <div>
                      <span>{person.role}</span>
                      <h4>{person.name}</h4>
                      <p>{person.copy}</p>
                    </div>
                  </article>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="technical-section" aria-labelledby="technical-title">
          <figure>
            <Image
              src="/images/instagram-coaching.jpg"
              alt="A Phoenix coach leading a session on the training pitch"
              fill
              unoptimized
              sizes="(max-width: 820px) 100vw, 48vw"
              style={{ objectFit: "cover", objectPosition: "center 14%" }}
            />
            <figcaption>Led by football people</figcaption>
          </figure>
          <div className="technical-copy">
            <p className="final-kicker">Who you learn from</p>
            <h2 id="technical-title">Clear experience. Clear responsibilities.</h2>
            <p>
              Club management, technical work, recruitment and ambassadorial
              support each have a distinct role inside the Phoenix environment.
            </p>
            <div className="technical-ledger">
              {learningPeople.map((person) => (
                <article key={person.name}>
                  <span>{person.role}</span>
                  <h3>{person.name}</h3>
                  <p>{person.copy}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="manchester-section" aria-labelledby="manchester-title">
          <div className="manchester-copy">
            <p className="final-kicker">Radcliffe FC partnership</p>
            <h2 id="manchester-title">Manchester roots. Dubai future.</h2>
            <p>
              Radcliffe FC is central to the Manchester connection, bringing a
              community-rooted English football environment into the wider
              Phoenix network.
            </p>
            <p>
              Radcliffe remains its own club, with its own identity, supporters
              and history. The partnership connects football thinking and
              people across Manchester and Dubai.
            </p>
            <a
              className="text-link"
              href="https://radcliffefc.com/"
              target="_blank"
              rel="noreferrer"
            >
              Visit Radcliffe FC <span aria-hidden="true">↗</span>
            </a>
          </div>
          <figure>
            <Image
              src="/media/radcliffe-partnership.jpeg"
              alt="Phoenix and Radcliffe FC representatives formalising the partnership"
              fill
              unoptimized
              sizes="(max-width: 820px) 100vw, 58vw"
            />
            <figcaption>
              <span>MAN 02</span>
              Phoenix × Radcliffe FC
            </figcaption>
          </figure>
        </section>

        <section className="club-network" aria-labelledby="network-title">
          <div className="network-heading">
            <p className="final-kicker">International network</p>
            <h2 id="network-title">Start in Dubai. Go further.</h2>
            <p>
              The core football route runs from Dubai to Manchester and Silves
              in the Algarve. The United States sits as a separate assessed
              pathway branch.
            </p>
          </div>
          <div className="network-route" aria-hidden="true">
            <span className="is-active">DXB</span>
            <i />
            <span>MAN</span>
            <i />
            <span>ALG</span>
          </div>
          <div className="network-stops">
            {networkStops.map((stop, index) => (
              <article className={index === 0 ? "is-active" : ""} key={stop.code}>
                <div className="network-image">
                  <Image
                    src={stop.image}
                    alt={stop.alt}
                    fill
                    unoptimized
                    sizes="(max-width: 820px) 100vw, 33vw"
                  />
                </div>
                <div className="network-meta">
                  <span>{stop.code}</span>
                  <strong>{stop.role}</strong>
                </div>
                <p>
                  {stop.city} · {stop.country}
                </p>
                <h3>{stop.club}</h3>
                <div>{stop.copy}</div>
              </article>
            ))}
          </div>
          <aside className="network-branch" aria-labelledby="usa-branch-title">
            <span>USA branch</span>
            <h3 id="usa-branch-title">FFF USA · scholarship preparation</h3>
            <p>
              A separate route based on academic eligibility, player fit and
              recruitment assessment. Scholarships are never guaranteed.
            </p>
          </aside>
          <Link className="button button-primary" href="/pathway">
            Explore the Pathway
          </Link>
        </section>

        <section className="culture-section" aria-labelledby="culture-title">
          <div className="culture-copy">
            <p className="final-kicker">Kits as Culture</p>
            <h2 id="culture-title">Wear the rise.</h2>
            <p>
              Matchday, training and supporter pieces carry the same Phoenix
              identity. The 26/27 preview introduces the collection through the
              club&apos;s approved product renders.
            </p>
            <Image
              className="culture-slogan"
              src="/brand/arabic-slogan-transparent.png"
              width={1415}
              height={951}
              alt="Strive to Rise in Arabic calligraphy"
              unoptimized
            />
            <Link className="button button-secondary" href="/store">
              Explore the Store
            </Link>
          </div>
          <figure className="culture-product-preview">
            <Image
              src="/kits/matchday-black-front.webp"
              alt="Phoenix black and gold matchday shirt preview"
              fill
              unoptimized
              sizes="(max-width: 820px) 100vw, 48vw"
              style={{ objectFit: "contain", objectPosition: "center" }}
            />
            <figcaption>Phoenix 26/27 · Matchday collection preview</figcaption>
          </figure>
        </section>

        <section
          id="partners"
          className="partners-section partners-logos-only"
          aria-labelledby="partners-title"
        >
          <div className="partners-heading">
            <p className="final-kicker">Partners</p>
            <h2 id="partners-title">Phoenix club partners.</h2>
          </div>
          <PartnerRail partners={approvedPartnerLogos} />
        </section>

        <section id="press" className="press-section" aria-labelledby="press-title">
          <div className="press-heading">
            <p className="final-kicker">Press & announcements</p>
            <h2 id="press-title">Official news, linked at source.</h2>
            <p>
              Partnership announcements, verified media coverage and club news
              will appear here only after they are published.
            </p>
          </div>
          <div className="press-placeholder" aria-label="Press room status">
            <span>Press room</span>
            <strong>Announcements will be added when they go live.</strong>
          </div>
          <a
            className="text-link"
            href="mailto:amer@phoenixutd.com?subject=Phoenix%20United%20media%20enquiry"
          >
            Media enquiries <span aria-hidden="true">→</span>
          </a>
        </section>

        <section className="club-close" aria-labelledby="club-close-title">
          <div className="club-close-copy">
            <p className="final-kicker">The next move starts with fit</p>
            <h2 id="club-close-title">Ready to rise with Phoenix?</h2>
            <p>
              Players and families can begin with the pathway assessment. Clubs,
              universities, sponsors and partners can open a separate conversation.
            </p>
            <div className="final-actions">
              <Link className="button button-primary" href="/pathway#assessment">
                Start Your Pathway
              </Link>
              <Link
                className="button button-secondary"
                href="/pathway?enquiry=partner#assessment"
              >
                Partner With Us
              </Link>
              <Link className="text-link" href="/store">
                Visit the Store <span aria-hidden="true">→</span>
              </Link>
            </div>
          </div>
          <aside className="club-close-board" aria-label="Phoenix route room">
            <p className="final-kicker">Route room</p>
            <ol>
              <li>
                <span>DXB 01</span>
                <strong>Phoenix United FC</strong>
                <small>Home</small>
              </li>
              <li>
                <span>MAN 02</span>
                <strong>Radcliffe FC</strong>
                <small>Connect</small>
              </li>
              <li>
                <span>ALG 03</span>
                <strong>Silves FC</strong>
                <small>Develop</small>
              </li>
            </ol>
            <p>Football · Education · Ecosystem</p>
          </aside>
        </section>
      </main>
      <SiteFooter />
      <TrackingConsent />
    </div>
  );
}
