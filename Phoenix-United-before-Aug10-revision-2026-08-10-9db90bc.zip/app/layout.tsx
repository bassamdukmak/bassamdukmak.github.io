import type { Metadata, Viewport } from "next";
import { headers } from "next/headers";
import "@fontsource-variable/anybody/wdth.css";
import "@fontsource-variable/noto-kufi-arabic";
import "@fontsource-variable/public-sans";
import "./phoenix.css";
import LanguageController from "./components/language-controller";

export async function generateMetadata(): Promise<Metadata> {
  const requestHeaders = await headers();
  const host =
    requestHeaders.get("x-forwarded-host") ??
    requestHeaders.get("host") ??
    "phoenixutd.com";
  const protocol =
    requestHeaders.get("x-forwarded-proto") ??
    (host.includes("localhost") ? "http" : "https");
  const metadataBase = new URL(`${protocol}://${host}`);

  return {
    metadataBase,
    title: {
      default: "Phoenix United FC | Football Club in Dubai",
      template: "%s | Phoenix United FC",
    },
    description:
      "Phoenix United FC is a UAE FA licensed football club in Dubai and the competitive heart of an international football and education ecosystem.",
    applicationName: "Phoenix United FC",
    alternates: {
      canonical: "/",
    },
    icons: {
      icon: "/brand/phoenix-flame.svg",
      shortcut: "/brand/phoenix-flame.svg",
      apple: "/brand/phoenix-flame.svg",
    },
    openGraph: {
      type: "website",
      url: "/",
      siteName: "Phoenix United FC",
      title: "Phoenix United FC | A football club in Dubai, built to rise.",
      description:
        "Explore the club, its people and the Phoenix Football Network connecting players from Dubai to Manchester, Portugal and beyond.",
      images: [
        {
          url: "/og.png",
          width: 1200,
          height: 630,
          alt: "Phoenix United FC — a football club in Dubai, built to rise.",
        },
      ],
    },
    twitter: {
      card: "summary_large_image",
      title: "Phoenix United FC | A football club in Dubai, built to rise.",
      description:
        "A real football club, culture and international pathway built from Dubai.",
      images: ["/og.png"],
    },
    robots: {
      index: true,
      follow: true,
    },
  };
}

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#0D0D0D",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const organization = {
    "@context": "https://schema.org",
    "@type": "SportsOrganization",
    name: "Phoenix United FC",
    url: "https://phoenixutd.com",
    sameAs: ["https://www.instagram.com/phoenix_utdfc"],
    address: {
      "@type": "PostalAddress",
      addressLocality: "Dubai",
      addressCountry: "AE",
    },
  };

  return (
    <html lang="en">
      <body>
        <LanguageController />
        {children}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(organization) }}
        />
      </body>
    </html>
  );
}
