"use client";

import { FormEvent, useRef, useState } from "react";
import Link from "next/link";
import styles from "../store/store.module.css";

type CollectionInterest =
  | "matchday"
  | "training"
  | "coaches"
  | "fan_supporter"
  | "premium_limited"
  | "not_sure";

type KitInterestForm = {
  fullName: string;
  email: string;
  phone: string;
  country: string;
  collectionInterest: CollectionInterest | "";
  message: string;
  consent: boolean;
  website: string;
};

type FormStatus = "idle" | "saving" | "saved" | "duplicate" | "error";
type FormErrors = Partial<Record<keyof KitInterestForm, string>>;

const INITIAL_FORM: KitInterestForm = {
  fullName: "",
  email: "",
  phone: "",
  country: "",
  collectionInterest: "",
  message: "",
  consent: false,
  website: "",
};

const COLLECTIONS: ReadonlyArray<{
  value: CollectionInterest;
  label: string;
}> = [
  { value: "matchday", label: "Matchday" },
  { value: "training", label: "Training" },
  { value: "coaches", label: "Coaches’ Wear" },
  { value: "fan_supporter", label: "Fan & Supporter" },
  { value: "premium_limited", label: "Premium Limited" },
  { value: "not_sure", label: "Not sure yet" },
];

function createSubmissionKey() {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    return crypto.randomUUID();
  }
  return `phoenix-${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

function validEmail(value: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim());
}

function validate(form: KitInterestForm) {
  const errors: FormErrors = {};
  if (form.fullName.trim().length < 2) {
    errors.fullName = "Enter your full name.";
  }
  if (!validEmail(form.email)) {
    errors.email = "Enter a valid email address.";
  }
  if (
    form.phone.trim() &&
    form.phone.replace(/[^\d]/g, "").length < 7
  ) {
    errors.phone = "Enter a valid WhatsApp number or leave it blank.";
  }
  if (form.country.trim().length < 2) {
    errors.country = "Enter your current country.";
  }
  if (!form.collectionInterest) {
    errors.collectionInterest = "Choose the collection you want to follow.";
  }
  if (!form.consent) {
    errors.consent = "Consent is required so Phoenix can contact you.";
  }
  return errors;
}

function readAttribution() {
  const params = new URLSearchParams(window.location.search);
  return {
    sourceUrl: window.location.href,
    referrer: document.referrer,
    utmSource: params.get("utm_source") ?? "",
    utmMedium: params.get("utm_medium") ?? "",
    utmCampaign: params.get("utm_campaign") ?? "",
    utmContent: params.get("utm_content") ?? "",
    utmTerm: params.get("utm_term") ?? "",
    gclid: params.get("gclid") ?? "",
    fbclid: params.get("fbclid") ?? "",
  };
}

function currentTimezone() {
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone || "";
  } catch {
    return "";
  }
}

export function KitInterest() {
  const [form, setForm] = useState(INITIAL_FORM);
  const [errors, setErrors] = useState<FormErrors>({});
  const [status, setStatus] = useState<FormStatus>("idle");
  const [feedback, setFeedback] = useState("");
  const [leadReference, setLeadReference] = useState("");
  const [idempotencyKey] = useState(createSubmissionKey);
  const [formStartedAt] = useState(() => Date.now());
  const formRef = useRef<HTMLFormElement>(null);

  function updateField<Key extends keyof KitInterestForm>(
    key: Key,
    value: KitInterestForm[Key],
  ) {
    setForm((current) => ({ ...current, [key]: value }));
    setErrors((current) => ({ ...current, [key]: undefined }));
    if (status === "error") {
      setStatus("idle");
      setFeedback("");
    }
  }

  function focusFirstError() {
    window.requestAnimationFrame(() => {
      formRef.current
        ?.querySelector<HTMLElement>('[aria-invalid="true"]')
        ?.focus();
    });
  }

  async function submitInterest(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (status === "saving" || status === "saved" || status === "duplicate") {
      return;
    }

    const nextErrors = validate(form);
    if (Object.keys(nextErrors).length > 0) {
      setErrors(nextErrors);
      setStatus("error");
      setFeedback("Complete the highlighted details before submitting.");
      focusFirstError();
      return;
    }

    setErrors({});
    setStatus("saving");
    setFeedback("Saving your kit interest…");

    try {
      const response = await fetch("/api/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          leadType: "kit_interest",
          idempotencyKey,
          formStartedAt,
          formVariant: "store_interest_v1",
          fullName: form.fullName,
          email: form.email,
          phone: form.phone,
          country: form.country,
          collectionInterest: form.collectionInterest,
          message: form.message,
          consent: form.consent,
          website: form.website,
          ...readAttribution(),
          language: navigator.language || "en",
          timezone: currentTimezone(),
        }),
      });

      const result = (await response.json().catch(() => ({}))) as {
        created?: boolean;
        error?: string;
        leadReference?: string;
        message?: string;
      };

      if (!response.ok) {
        throw new Error(result.error || "The request could not be saved.");
      }
      if (
        (result.created !== true && result.created !== false) ||
        !result.leadReference
      ) {
        throw new Error("Phoenix could not confirm that your request was saved.");
      }

      setLeadReference(result.leadReference);
      if (result.created) {
        setStatus("saved");
        setFeedback(
          result.message ||
            "Your interest is registered. Phoenix will contact you when there is an approved update for this collection.",
        );
      } else {
        setStatus("duplicate");
        setFeedback(
          result.message ||
            "Your interest is already safely registered. There is no need to submit twice.",
        );
      }
    } catch (error) {
      setStatus("error");
      setFeedback(
        error instanceof Error
          ? `${error.message} Please retry, or email amer@phoenixutd.com.`
          : "The request could not be saved. Please retry, or email amer@phoenixutd.com.",
      );
      window.requestAnimationFrame(() => {
        document.getElementById("kit-interest-feedback")?.focus();
      });
    }
  }

  const completed = status === "saved" || status === "duplicate";

  return (
    <form
      ref={formRef}
      className={styles.interestForm}
      onSubmit={submitInterest}
      noValidate
    >
      <div className={styles.formGrid}>
        <label className={styles.field}>
          <span>Full name *</span>
          <input
            name="fullName"
            autoComplete="name"
            value={form.fullName}
            onChange={(event) => updateField("fullName", event.target.value)}
            aria-invalid={Boolean(errors.fullName)}
            aria-describedby={errors.fullName ? "kit-name-error" : undefined}
            disabled={completed}
          />
          {errors.fullName ? (
            <small id="kit-name-error">{errors.fullName}</small>
          ) : null}
        </label>

        <label className={styles.field}>
          <span>Email *</span>
          <input
            name="email"
            type="email"
            autoComplete="email"
            value={form.email}
            onChange={(event) => updateField("email", event.target.value)}
            aria-invalid={Boolean(errors.email)}
            aria-describedby={errors.email ? "kit-email-error" : undefined}
            disabled={completed}
          />
          {errors.email ? (
            <small id="kit-email-error">{errors.email}</small>
          ) : null}
        </label>

        <label className={styles.field}>
          <span>WhatsApp</span>
          <input
            name="phone"
            type="tel"
            autoComplete="tel"
            placeholder="Include country code"
            value={form.phone}
            onChange={(event) => updateField("phone", event.target.value)}
            aria-invalid={Boolean(errors.phone)}
            aria-describedby={errors.phone ? "kit-phone-error" : undefined}
            disabled={completed}
          />
          {errors.phone ? (
            <small id="kit-phone-error">{errors.phone}</small>
          ) : null}
        </label>

        <label className={styles.field}>
          <span>Country *</span>
          <input
            name="country"
            autoComplete="country-name"
            value={form.country}
            onChange={(event) => updateField("country", event.target.value)}
            aria-invalid={Boolean(errors.country)}
            aria-describedby={errors.country ? "kit-country-error" : undefined}
            disabled={completed}
          />
          {errors.country ? (
            <small id="kit-country-error">{errors.country}</small>
          ) : null}
        </label>

        <label className={`${styles.field} ${styles.fullField}`}>
          <span>Collection interest *</span>
          <select
            name="collectionInterest"
            value={form.collectionInterest}
            onChange={(event) =>
              updateField(
                "collectionInterest",
                event.target.value as CollectionInterest | "",
              )
            }
            aria-invalid={Boolean(errors.collectionInterest)}
            aria-describedby={
              errors.collectionInterest ? "kit-collection-error" : undefined
            }
            disabled={completed}
          >
            <option value="">Choose a collection</option>
            {COLLECTIONS.map((collection) => (
              <option key={collection.value} value={collection.value}>
                {collection.label}
              </option>
            ))}
          </select>
          {errors.collectionInterest ? (
            <small id="kit-collection-error">
              {errors.collectionInterest}
            </small>
          ) : null}
        </label>

        <label className={`${styles.field} ${styles.fullField}`}>
          <span>Anything Phoenix should know?</span>
          <textarea
            name="message"
            rows={4}
            maxLength={1200}
            value={form.message}
            onChange={(event) => updateField("message", event.target.value)}
            disabled={completed}
          />
        </label>

        <label className={styles.honeypot} aria-hidden="true">
          Website
          <input
            name="website"
            tabIndex={-1}
            autoComplete="off"
            value={form.website}
            onChange={(event) => updateField("website", event.target.value)}
          />
        </label>

        <label className={`${styles.consent} ${styles.fullField}`}>
          <input
            name="consent"
            type="checkbox"
            checked={form.consent}
            onChange={(event) => updateField("consent", event.target.checked)}
            aria-invalid={Boolean(errors.consent)}
            aria-describedby={errors.consent ? "kit-consent-error" : undefined}
            disabled={completed}
          />
          <span>
            I agree that Phoenix may use these details to respond to my kit
            interest. See the <Link href="/privacy">privacy notice</Link>.
          </span>
          {errors.consent ? (
            <small id="kit-consent-error">{errors.consent}</small>
          ) : null}
        </label>
      </div>

      <div className={styles.formFooter}>
        <button type="submit" disabled={status === "saving" || completed}>
          {status === "saving"
            ? "Registering…"
            : completed
              ? "Interest registered"
              : "Register interest"}
        </button>
        <p>Preview only. No purchase or reservation is being taken.</p>
      </div>

      <div
        id="kit-interest-feedback"
        className={`${styles.formFeedback} ${
          status === "error" ? styles.formFeedbackError : ""
        }`}
        role={status === "error" ? "alert" : "status"}
        aria-live="polite"
        tabIndex={-1}
      >
        {feedback}
        {leadReference ? (
          <span className={styles.leadReference}>Ref. {leadReference}</span>
        ) : null}
      </div>
    </form>
  );
}
