"use client";

/* eslint-disable @next/next/no-img-element */

import { useState } from "react";
import type { PartnerLogo } from "../content/site-content";

function PartnerMark({
  partner,
  onError,
}: {
  partner: PartnerLogo;
  onError: (logo: string) => void;
}) {
  const image = (
    <img
      src={partner.logo}
      width={220}
      height={112}
      alt={partner.name}
      loading="lazy"
      decoding="async"
      onError={() => onError(partner.logo)}
    />
  );

  if (!partner.href) return image;

  return (
    <a
      href={partner.href}
      target="_blank"
      rel="noreferrer"
      aria-label={`Visit ${partner.name}`}
    >
      {image}
    </a>
  );
}

export default function PartnerRail({ partners }: { partners: PartnerLogo[] }) {
  const [failedLogos, setFailedLogos] = useState<Set<string>>(() => new Set());
  const visiblePartners = partners.filter(
    (partner) =>
      partner.status === "published" && !failedLogos.has(partner.logo),
  );

  function hideMissingLogo(logo: string) {
    setFailedLogos((current) => {
      const next = new Set(current);
      next.add(logo);
      return next;
    });
  }

  if (visiblePartners.length === 0) return null;

  return (
    <ul
      className="partner-grid"
      aria-label="Phoenix partner organisations"
    >
      {visiblePartners.map((partner) => (
        <li key={partner.name}>
          <PartnerMark partner={partner} onError={hideMissingLogo} />
        </li>
      ))}
    </ul>
  );
}
