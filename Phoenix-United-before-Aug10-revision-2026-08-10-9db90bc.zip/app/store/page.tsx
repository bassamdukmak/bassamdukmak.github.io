import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { KitInterest } from "../components/kit-interest";
import { ProductViewer } from "../components/product-viewer";
import {
  SiteFooter,
  SiteHeader,
  TrackingConsent,
} from "../components/site-chrome";
import {
  kitFeatures,
  storeCollections,
  type KitFeature,
} from "../content/kit-media";
import styles from "./store.module.css";

export const metadata: Metadata = {
  title: {
    absolute: "Phoenix Store | Wear the Rise",
  },
  description:
    "Preview Phoenix United matchday, training and football-fashion collections, and register for approved release updates.",
  alternates: {
    canonical: "/store",
  },
  openGraph: {
    type: "website",
    url: "/store",
    siteName: "Phoenix United FC",
    title: "Phoenix Store | Wear the Rise",
    description:
      "Phoenix United matchday, training and football-fashion previews.",
    images: [
      {
        url: "/og.png",
        width: 1200,
        height: 630,
        alt: "Phoenix United FC — club identity built from Dubai.",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Phoenix Store | Wear the Rise",
    description:
      "Phoenix United matchday, training and football-fashion previews.",
    images: ["/og.png"],
  },
};

function EditorialSlot({ feature }: { feature: KitFeature }) {
  const media = feature.editorialImage ?? feature.views[0].image;
  const hasPhotography = Boolean(feature.editorialImage);

  return (
    <figure
      className={`${styles.editorialSlot} ${
        hasPhotography ? styles.editorialPhoto : styles.editorialRender
      }`}
      data-media-state={hasPhotography ? "photoshoot" : "render-preview"}
    >
      <Image
        src={media.src}
        alt={media.alt}
        fill
        priority
        sizes="(max-width: 900px) 100vw, 58vw"
        unoptimized
        style={{
          objectFit: hasPhotography ? "cover" : "contain",
          objectPosition: media.objectPosition ?? "center",
        }}
      />
      <figcaption>
        <span>{feature.category}</span>
        <strong>{feature.status}</strong>
      </figcaption>
    </figure>
  );
}

export default function StorePage() {
  const leadFeature = kitFeatures[0];

  return (
    <div className={`final-site ${styles.store}`}>
      <SiteHeader activePage="store" />
      <main id="main-content">
        <section className={styles.hero} aria-labelledby="store-title">
          <div className={styles.heroCopy}>
            <div className={styles.heroMark}>
              <Image
                src="/brand/phoenix-flame.svg"
                width={54}
                height={67}
                alt=""
                aria-hidden="true"
                unoptimized
              />
              <p>Kits as Culture · 26/27 Preview</p>
            </div>
            <h1 id="store-title">
              Wear the <span>rise.</span>
            </h1>
            <p className={styles.heroIntro}>
              Club identity made for matchday, the training ground and the city.
            </p>
            <div className={styles.heroActions}>
              <a href="#kit-preview">View the kits</a>
              <a href="#register-interest">Register interest</a>
            </div>
            <p className={styles.previewNote}>
              Preview collection. Release details will be announced by Phoenix.
            </p>
          </div>
          <EditorialSlot feature={leadFeature} />
        </section>

        <section className={styles.collectionIndex} aria-labelledby="collections-title">
          <header>
            <p>Collection architecture</p>
            <h2 id="collections-title">One badge. Five expressions.</h2>
          </header>
          <div className={styles.collectionList}>
            {storeCollections.map((collection) => (
              <article key={collection.number}>
                <span>{collection.number}</span>
                <div>
                  <h3>{collection.title}</h3>
                  <p>{collection.description}</p>
                </div>
                <strong>{collection.marker}</strong>
              </article>
            ))}
          </div>
        </section>

        <section
          className={styles.productSection}
          id="kit-preview"
          aria-labelledby="kit-preview-title"
        >
          <header className={styles.productHeading}>
            <p>Kit previews</p>
            <h2 id="kit-preview-title">Built around the Phoenix.</h2>
            <p>
              Explore the matchday, training and technical collection through
              the club&apos;s approved product renders.
            </p>
          </header>

          <div className={styles.productGrid}>
            {kitFeatures.map((feature) => (
              <article className={styles.productCard} key={feature.id}>
                <ProductViewer feature={feature} />
                <div className={styles.productCopy}>
                  <div className={styles.productMeta}>
                    <span>{feature.number}</span>
                    <span>{feature.category}</span>
                    <span>{feature.status}</span>
                  </div>
                  <h3>{feature.title}</h3>
                  <p>{feature.description}</p>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className={styles.futureCollection} aria-labelledby="future-title">
          <div className={styles.futureIndex}>05</div>
          <div>
            <p>Future collection</p>
            <h2 id="future-title">Made with the right partners.</h2>
          </div>
          <p>
            A future platform for approved club, sponsor and creative
            collaborations—released only when the product and story are ready.
          </p>
        </section>

        <section
          className={styles.interestSection}
          id="register-interest"
          aria-labelledby="interest-title"
        >
          <div className={styles.interestHeading}>
            <p>Release updates</p>
            <h2 id="interest-title">Tell us what you want to wear.</h2>
            <p>
              Register for approved kit and collection updates. This is not a
              purchase, reservation or promise of stock.
            </p>
            <Image
              src="/brand/phoenix-united-wordmark.svg"
              width={330}
              height={100}
              alt="Phoenix United"
              unoptimized
            />
          </div>
          <KitInterest />
        </section>

        <section className={styles.storeClose} aria-labelledby="store-close-title">
          <Image
            src="/brand/phoenix-crest.svg"
            width={88}
            height={126}
            alt="Phoenix United FC crest"
            unoptimized
          />
          <div>
            <p>Football · Fashion · Community</p>
            <h2 id="store-close-title">The badge travels.</h2>
          </div>
          <Link href="/">Explore the Club</Link>
        </section>
      </main>
      <SiteFooter />
      <TrackingConsent />
    </div>
  );
}
