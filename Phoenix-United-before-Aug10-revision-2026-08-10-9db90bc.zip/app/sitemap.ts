import type { MetadataRoute } from "next";

export default function sitemap(): MetadataRoute.Sitemap {
  return [
    {
      url: "https://phoenixutd.com",
      lastModified: new Date("2026-07-29"),
      changeFrequency: "weekly",
      priority: 1,
    },
    {
      url: "https://phoenixutd.com/pathway",
      lastModified: new Date("2026-07-29"),
      changeFrequency: "weekly",
      priority: 0.9,
    },
    {
      url: "https://phoenixutd.com/store",
      lastModified: new Date("2026-07-29"),
      changeFrequency: "monthly",
      priority: 0.5,
    },
    {
      url: "https://phoenixutd.com/privacy",
      lastModified: new Date("2026-07-29"),
      changeFrequency: "monthly",
      priority: 0.3,
    },
  ];
}
