import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import PathwayAssessment from "../components/pathway-assessment";
import {
  SiteFooter,
  SiteHeader,
  TrackingConsent,
} from "../components/site-chrome";

export const metadata: Metadata = {
  title: {
    absolute: "Phoenix Football Network | Football. Degree. Pathway.",
  },
  description:
    "A connected football and education pathway for players aged 18–25, with routes through Dubai, Manchester, Portugal and the United States.",
  alternates: {
    canonical: "/pathway",
  },
  openGraph: {
    type: "website",
    url: "/pathway",
    siteName: "Phoenix United FC",
    title: "Phoenix Football Network | Start Your Pathway",
    description:
      "Train with purpose. Play with direction. Explore football, degree, camp and international routes through Phoenix.",
    images: [
      {
        url: "/og.png",
        width: 1200,
        height: 630,
        alt: "Phoenix United FC — Dubai, Manchester and Portugal pathway.",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Phoenix Football Network | Start Your Pathway",
    description:
      "Train with purpose. Play with direction. Explore football, degree, camp and international routes through Phoenix.",
    images: ["/og.png"],
  },
};

const programmeTracks = [
  {
    marker: "Train",
    title: "A serious football week",
    copy: "Club training, competition, analysis and physical preparation organised around one football environment.",
    signal: "Dubai · UAE",
  },
  {
    marker: "Study",
    title: "An accredited degree route",
    copy: "Academic timetabling and support designed to coexist with the football schedule, with institution details confirmed before enrolment.",
    signal: "UK / US route",
  },
  {
    marker: "Move",
    title: "More than one next step",
    copy: "Club, camp, showcase, US college and career conversations based on fit—not a promised outcome.",
    signal: "MAN · ALG · USA",
  },
];

const pathwayRoutes = [
  {
    code: "DXB 01",
    place: "Dubai · UAE",
    title: "The home of the ecosystem",
    copy: "Phoenix United FC, the daily football environment, the education base and the starting point for assessment.",
    image: "/images/dubai-hub.jpg",
    alt: "Phoenix players standing together after training in Dubai",
  },
  {
    code: "MAN 02",
    place: "Manchester · England",
    title: "The UK football connection",
    copy: "Radcliffe FC, Manchester football culture and an English-club environment connected to the network.",
    image: "/images/manchester-hub.jpg",
    alt: "Radcliffe FC supporters in the stand in Greater Manchester",
  },
  {
    code: "ALG 03",
    place: "Algarve · Portugal",
    title: "The European environment",
    copy: "Silves FC, camps, showcases and development activity inside the Portuguese football setting.",
    image: "/images/algarve-hub.jpg",
    alt: "Phoenix representatives at a football ground in Portugal",
  },
];

const process = [
  {
    title: "Submit the player assessment",
    copy: "Share football, education, location and route context so the first review starts with useful information.",
  },
  {
    title: "Phoenix reviews the profile",
    copy: "The team considers current level, readiness, preferred location and the route being requested.",
  },
  {
    title: "Book the evaluation conversation",
    copy: "If the profile is relevant, Phoenix arranges a direct conversation with the player or family.",
  },
  {
    title: "Clarify the best route",
    copy: "The conversation identifies the most credible club, degree, camp or US-pathway starting point.",
  },
  {
    title: "Receive the next steps",
    copy: "Phoenix explains what evidence, dates, costs and commitments need to be confirmed before anyone proceeds.",
  },
];

const faqs = [
  {
    question: "Is Phoenix a football club or a programme?",
    answer:
      "Both exist, but they are separate. Phoenix United FC is the club. Phoenix Football Network is the programme and pathway system connecting football, education, camps and international routes.",
  },
  {
    question: "Who is the main pathway built for?",
    answer:
      "The main football education pathway is designed for ambitious players aged 18–25. Camps, showcases and other activity can include different age groups when specifically announced.",
  },
  {
    question: "Is a place, scholarship or playing time guaranteed?",
    answer:
      "No. The assessment starts a review. Programme admission, squad selection, minutes, scholarships, transfers and professional opportunities are assessed or earned, never guaranteed by submitting a form.",
  },
  {
    question: "Can a player choose football without the degree?",
    answer:
      "Yes. Football + Degree and Football Only are separate routes. The assessment also includes international camps, US scholarship preparation and a Not Sure Yet option.",
  },
  {
    question: "How is the education route confirmed?",
    answer:
      "Before enrolment, Phoenix should confirm the named institution, accreditation, delivery format, academic schedule, admissions requirements and costs that apply to the individual route. The website does not invent those details.",
  },
  {
    question: "Is accommodation available?",
    answer:
      "Location-specific accommodation, welfare, transport and visa details are discussed with the family during follow-up and confirmed before any commitment.",
  },
  {
    question: "What happens after I submit?",
    answer:
      "Phoenix saves the assessment, reviews it and contacts the applicant about the most suitable next step. A reference is shown only after the submission is safely stored.",
  },
];

export default function PathwayPage() {
  return (
    <div className="final-site pathway-page">
      <SiteHeader activePage="pathway" />
      <main id="main-content">

      <section className="pathway-hero" aria-labelledby="pathway-hero-title">
        <div className="pathway-hero-copy">
          <div className="network-lockup">
            <Image
              src="/brand/phoenix-flame.svg"
              width={70}
              height={77}
              alt=""
              aria-hidden="true"
              unoptimized
            />
            <p>
              Phoenix Football Network
              <span>Football · Degree · Pathway</span>
            </p>
          </div>
          <p className="final-kicker">The pathway system</p>
          <h1 id="pathway-hero-title">
            Train with purpose. <em>Play with direction.</em>
          </h1>
          <p className="pathway-hero-lede">
            A connected football and education pathway for players who want to
            train, compete, study and build a credible next step through Dubai,
            Manchester, Portugal or the US route.
          </p>
          <div className="final-actions">
            <a className="button button-primary" href="#assessment">
              Start Your Pathway
            </a>
            <a
              className="button button-secondary"
              href="mailto:amer@phoenixutd.com?subject=Phoenix%20Football%20Network"
            >
              Speak to the Team
            </a>
          </div>
        </div>
        <figure className="pathway-hero-media">
          <Image
            src="/images/instagram-training.jpg"
            alt="A Phoenix player working with the ball during training"
            fill
            priority
            unoptimized
            sizes="(max-width: 820px) 100vw, 44vw"
          />
          <figcaption>
            <span>Player pathway</span>
            Football and education on one timetable
          </figcaption>
        </figure>
        <div className="pathway-route-board" aria-label="Phoenix pathway routes">
          <a className="is-active" href="#routes">
            <span>DXB 01</span>
            <strong>Dubai</strong>
            <small>Start</small>
          </a>
          <a href="#routes">
            <span>MAN 02</span>
            <strong>Manchester</strong>
            <small>Connect</small>
          </a>
          <a href="#routes">
            <span>ALG 03</span>
            <strong>Portugal</strong>
            <small>Develop</small>
          </a>
          <a className="is-branch" href="#routes">
            <span>USA</span>
            <strong>College route</strong>
            <small>Assess</small>
          </a>
        </div>
      </section>

      <section
        className="pathway-manifesto"
        aria-labelledby="pathway-manifesto-title"
      >
        <p className="final-kicker">The complete route</p>
        <h2 id="pathway-manifesto-title">
          <span>Football.</span>
          <span>Degree.</span>
          <span>Pathway.</span>
        </h2>
        <dl>
          <div>
            <dt>Football</dt>
            <dd>Train and compete inside a serious club environment.</dd>
          </div>
          <div>
            <dt>Degree</dt>
            <dd>Build education around the demands of the football week.</dd>
          </div>
          <div>
            <dt>Pathway</dt>
            <dd>Assess the next credible route without promising an outcome.</dd>
          </div>
        </dl>
      </section>

      <section className="brand-separation" aria-labelledby="separation-title">
        <div>
          <p className="final-kicker">What Phoenix Football Network is</p>
          <h2 id="separation-title">
            The club competes. The network connects the routes.
          </h2>
        </div>
        <article>
          <span>Phoenix United FC</span>
          <h3>The club</h3>
          <p>
            The competitive and cultural heart: players, coaches, training,
            matchday, supporters, partners and the badge.
          </p>
          <Link className="text-link" href="/">
            Explore the Club <span aria-hidden="true">→</span>
          </Link>
        </article>
        <article className="is-network">
          <span>Phoenix Football Network</span>
          <h3>The pathway</h3>
          <p>
            The programme system connecting football, degree routes, camps,
            partner clubs, US preparation and player assessment.
          </p>
          <a className="text-link" href="#assessment">
            Start the assessment <span aria-hidden="true">↓</span>
          </a>
        </article>
      </section>

      <section className="pathway-programme" aria-labelledby="programme-title">
        <div className="pathway-programme-heading">
          <p className="final-kicker">Football + education programme</p>
          <h2 id="programme-title">
            Train in the UAE. Study for a degree. Both, at the same time.
          </h2>
          <p>
            The week is designed around the player as a whole person. Football
            and education move together, with practical details confirmed
            before enrolment.
          </p>
        </div>
        <figure>
          <Image
            src="/images/instagram-coaching.jpg"
            alt="A coach leading a Phoenix football session"
            fill
            unoptimized
            sizes="(max-width: 820px) 100vw, 46vw"
            style={{ objectFit: "cover", objectPosition: "center 14%" }}
          />
          <figcaption>Real training environment · Dubai</figcaption>
        </figure>
        <div className="programme-tracks">
          {programmeTracks.map((track) => (
            <article key={track.marker}>
              <span>{track.marker}</span>
              <div>
                <h3>{track.title}</h3>
                <p>{track.copy}</p>
              </div>
              <strong>{track.signal}</strong>
            </article>
          ))}
        </div>
      </section>

      <section className="audience-section" aria-labelledby="audience-title">
        <div className="audience-heading">
          <p className="final-kicker">Who it is for</p>
          <h2 id="audience-title">A serious decision for players and families.</h2>
        </div>
        <article>
          <span>For the player</span>
          <h3>You want structure, not just another trial.</h3>
          <ul>
            <li>A serious daily football environment</li>
            <li>Football and education considered together</li>
            <li>International exposure without false promises</li>
            <li>More than one possible next step</li>
          </ul>
        </article>
        <article>
          <span>For the family</span>
          <h3>You need clarity before commitment.</h3>
          <ul>
            <li>Named providers and verified programme facts</li>
            <li>Clear training, education and welfare structure</li>
            <li>Direct discussion of costs and accommodation</li>
            <li>Honest language about possible outcomes</li>
          </ul>
        </article>
      </section>

      <section
        id="routes"
        className="pathway-routes"
        aria-labelledby="routes-title"
      >
        <div className="routes-heading">
          <p className="final-kicker">The routes</p>
          <h2 id="routes-title">Dubai is the base. The next move depends on fit.</h2>
          <p>
            The core club line runs Dubai → Manchester → Algarve. The US college
            route branches separately through eligibility, academic and
            recruitment assessment.
          </p>
        </div>
        <div className="route-line" aria-hidden="true">
          <span className="is-active">DXB</span>
          <i />
          <span>MAN</span>
          <i />
          <span>ALG</span>
          <b />
          <span className="is-us">USA</span>
        </div>
        <div className="route-chapters">
          {pathwayRoutes.map((route, index) => (
            <article className={index === 0 ? "is-active" : ""} key={route.code}>
              <figure>
                <Image
                  src={route.image}
                  alt={route.alt}
                  fill
                  unoptimized
                  sizes="(max-width: 820px) 100vw, 33vw"
                />
              </figure>
              <span>{route.code}</span>
              <p>{route.place}</p>
              <h3>{route.title}</h3>
              <div>{route.copy}</div>
            </article>
          ))}
          <article className="us-route">
            <div className="us-route-board">
              <div>
                <span>Branch 04</span>
                <strong>USA</strong>
              </div>
              <ol aria-label="US pathway assessment stages">
                <li>Eligibility</li>
                <li>Academics</li>
                <li>Footage</li>
                <li>Recruitment</li>
              </ol>
            </div>
            <span className="us-route-branch">Separate assessed branch</span>
            <p>United States</p>
            <h3>US scholarship preparation</h3>
            <div>
              Eligibility review, academics, player footage, recruitment
              guidance and coach exposure. A scholarship is never guaranteed.
            </div>
          </article>
        </div>
      </section>

      <section className="camps-section" aria-labelledby="camps-title">
        <figure>
          <Image
            src="/images/showcase-squad.jpg"
            alt="A full Phoenix showcase squad lined up across the pitch"
            fill
            unoptimized
            sizes="100vw"
          />
          <figcaption>Showcase environment · real Phoenix photography</figcaption>
        </figure>
        <div>
          <p className="final-kicker">Camps & showcases</p>
          <h2 id="camps-title">A first step into the Phoenix pathway.</h2>
          <p>
            Camps and showcases can combine coaching, assessment, competition
            and cultural exposure in Dubai, Manchester or Portugal. Strong
            performers are guided toward the next route that actually fits.
          </p>
          <ul>
            <li>International camps</li>
            <li>Player assessments</li>
            <li>Showcases and trial events</li>
            <li>Youth tournaments when announced</li>
          </ul>
          <a className="text-link" href="#assessment">
            Ask about camps <span aria-hidden="true">→</span>
          </a>
        </div>
      </section>

      <section className="process-section" aria-labelledby="process-title">
        <div className="process-heading">
          <p className="final-kicker">How players join</p>
          <h2 id="process-title">Assessment before recommendation.</h2>
          <p>
            The team needs enough context to give a useful answer. The form is
            structured for the CRM so nobody has to start the first call from
            zero.
          </p>
        </div>
        <ol>
          {process.map((step, index) => (
            <li key={step.title}>
              <span>{String(index + 1).padStart(2, "0")}</span>
              <div>
                <h3>{step.title}</h3>
                <p>{step.copy}</p>
              </div>
            </li>
          ))}
        </ol>
      </section>

      <section className="parent-proof" aria-labelledby="parent-title">
        <div>
          <p className="final-kicker">For parents & decision-makers</p>
          <h2 id="parent-title">Structure, safety, education and support.</h2>
          <p>
            Choosing a football education programme is a family decision. The
            evaluation should make the practical picture clearer before any
            commitment is requested.
          </p>
        </div>
        <dl>
          <div>
            <dt>Football</dt>
            <dd>Training base, coaching, competition and assessment standard.</dd>
          </div>
          <div>
            <dt>Education</dt>
            <dd>Named institution, accreditation, delivery and timetable.</dd>
          </div>
          <div>
            <dt>Living</dt>
            <dd>Accommodation, welfare, transport and location details.</dd>
          </div>
          <div>
            <dt>Investment</dt>
            <dd>Costs, inclusions, timing and what is not guaranteed.</dd>
          </div>
        </dl>
      </section>

      <section id="assessment" className="assessment-section">
        <div className="assessment-context">
          <p className="final-kicker">Start Your Pathway</p>
          <h2>Player Pathway Assessment</h2>
          <p>
            Share the context Phoenix needs to review the player properly. The
            form separates player and partnership enquiries and sends structured
            information into the lead workflow.
          </p>
          <div className="assessment-truth">
            <span>Honest pathway language</span>
            <p>
              Phoenix provides structure, coaching, education support and
              pathway access. Selection, playing time, scholarships, transfers
              and professional opportunities are earned or assessed—never
              guaranteed.
            </p>
          </div>
        </div>
        <PathwayAssessment />
      </section>

      <section
        className="honest-outcomes"
        aria-labelledby="outcomes-title"
      >
        <div>
          <p className="final-kicker">Honest outcomes</p>
          <h2 id="outcomes-title">Access is real. Outcomes are earned.</h2>
          <p>
            Phoenix provides a structured football environment, education
            coordination, assessment and access to pathway conversations. The
            next step always depends on the player, the route and the relevant
            decision-maker.
          </p>
        </div>
        <dl>
          <div>
            <dt>Phoenix provides</dt>
            <dd>Structure, coaching, assessment, education support and routes.</dd>
          </div>
          <div>
            <dt>Phoenix never guarantees</dt>
            <dd>
              Selection, playing time, contracts, scholarships, transfers or
              professional opportunities.
            </dd>
          </div>
        </dl>
      </section>

      <section className="pathway-faq" aria-labelledby="faq-title">
        <div>
          <p className="final-kicker">Straight answers</p>
          <h2 id="faq-title">Questions serious players and families ask first.</h2>
        </div>
        <div className="faq-list">
          {faqs.map((faq) => (
            <details key={faq.question}>
              <summary>
                <span>{faq.question}</span>
                <i aria-hidden="true">+</i>
              </summary>
              <p>{faq.answer}</p>
            </details>
          ))}
        </div>
      </section>

      <section className="pathway-close" aria-labelledby="pathway-close-title">
        <div className="route-close" aria-hidden="true">
          <span>DXB</span>
          <i />
          <span>MAN</span>
          <i />
          <span>ALG</span>
        </div>
        <p className="final-kicker">Beyond one opportunity</p>
        <h2 id="pathway-close-title">Start with the route that fits the player.</h2>
        <p>
          Complete the assessment and Phoenix will review the most credible
          next step—not the most dramatic promise.
        </p>
        <a className="button button-primary" href="#assessment">
          Complete Player Assessment
        </a>
      </section>

      </main>
      <SiteFooter />
      <TrackingConsent />
    </div>
  );
}
